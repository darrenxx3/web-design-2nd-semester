window.onload = function() { fungsiSaya(); }

function fungsiSaya() {

	/* DI BAWAH INI MERUPAKAN CONTOH PENGGUNAAN DOCUMENT OBJECT MODEL (DOM) */
	a = document.getElementsByTagName("title")[0].firstChild;
	a.nodeValue = "UMN";
	
	b = document.getElementById("footer").getElementsByTagName("p")[0].firstChild;
	b.nodeValue = "&copy;2019 UMN Students";
	
	/* TULISKAN SCRIPT ANDA DI SINI */
	var home = document.getElementById("menu").getElementsByTagName("a")[0].firstChild;
	home.nodeValue = "Utama";
	
	
}