$("button").toggle(function(){
	nama = $("input#nama").val();
	alert(nama);
});